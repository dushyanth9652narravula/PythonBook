print("Running pack1...")

value = "pack1 value"

from pack1.pack1_1 import values